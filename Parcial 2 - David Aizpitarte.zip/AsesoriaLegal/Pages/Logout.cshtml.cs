
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AsesoriaLegal.Pages
{
    public class LogoutModel : PageModel
    {
        public void OnGet()
        {
        }

        public IActionResult OnPost()
        {
            // Eliminar los datos de la sesión
            HttpContext.Session.Clear();

            // Eliminar la cookie del usuario
            Response.Cookies.Delete("UsuarioNombre");

            return RedirectToPage("/Index");
        }
    }
}
