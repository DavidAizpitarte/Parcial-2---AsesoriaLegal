
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Identity;
using Microsoft.Data.SqlClient;
using AsesoriaLegal.Datos;

namespace AsesoriaLegal.Pages
{
    public class LoginModel : PageModel
    {
        private readonly ConexionDB _conexion;

        public LoginModel(ConexionDB conexion)
        {
            _conexion = conexion;
        }

        [BindProperty]
        [Required(ErrorMessage = "Ingresá tu correo electrónico.")]
        [EmailAddress(ErrorMessage = "Ingresá un correo válido.")]
        [Display(Name = "Correo electrónico")]
        public string Correo { get; set; } = string.Empty;

        [BindProperty]
        [Required(ErrorMessage = "Ingresá tu contraseña.")]
        [DataType(DataType.Password)]
        [Display(Name = "Contraseña")]
        public string Password { get; set; } = string.Empty;

        public void OnGet()
        {
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
                return Page();

            using SqlConnection conexion = _conexion.ObtenerConexion();

            await conexion.OpenAsync();

            string consulta = @"
                SELECT Id, Nombre, PasswordHash
                FROM Usuarios
                WHERE Correo = @Correo";

            using SqlCommand comando = new(consulta, conexion);

            comando.Parameters.AddWithValue("@Correo", Correo);

            using SqlDataReader reader = await comando.ExecuteReaderAsync();

            if (!await reader.ReadAsync())
            {
                ModelState.AddModelError(string.Empty,
                    "El correo o la contraseña son incorrectos.");

                return Page();
            }

            int usuarioId = reader.GetInt32(0);
            string nombre = reader.GetString(1);
            string passwordHash = reader.GetString(2);

            var hasher = new PasswordHasher<string>();

            var resultado = hasher.VerifyHashedPassword(
                Correo,
                passwordHash,
                Password
            );

            if (resultado == PasswordVerificationResult.Failed)
            {
                ModelState.AddModelError(string.Empty,
                    "El correo o la contraseña son incorrectos.");

                return Page();
            }

            HttpContext.Session.SetInt32("UsuarioId", usuarioId);
            HttpContext.Session.SetString("UsuarioNombre", nombre);

            Response.Cookies.Append(
                "UsuarioNombre",
                nombre,
                new CookieOptions
                {
                    HttpOnly = true,
                    Secure = Request.IsHttps,
                    SameSite = SameSiteMode.Lax,
                    Expires = DateTimeOffset.Now.AddDays(7)
                });

            return RedirectToPage("/MiEspacio");
        }
    }
}
