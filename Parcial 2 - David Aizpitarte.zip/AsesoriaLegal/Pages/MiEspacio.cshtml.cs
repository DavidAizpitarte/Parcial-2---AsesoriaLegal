
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AsesoriaLegal.Pages
{
    public class MiEspacioModel : PageModel
    {
        public string NombreUsuario { get; set; } = string.Empty;

        public IActionResult OnGet()
        {
            // Comprobar si existe una sesión iniciada
            int? usuarioId = HttpContext.Session.GetInt32("UsuarioId");

            // Si no hay sesión, redirigir al Login
            if (usuarioId == null)
            {
                return RedirectToPage("/Login");
            }

            // Obtener el nombre del usuario desde la sesión
            NombreUsuario = HttpContext.Session.GetString("UsuarioNombre")
                ?? "Usuario";

            return Page();
        }
    }
}
