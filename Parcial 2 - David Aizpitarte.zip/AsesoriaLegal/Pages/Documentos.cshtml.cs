
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Data.SqlClient;
using Microsoft.AspNetCore.StaticFiles;
using AsesoriaLegal.Datos;

namespace AsesoriaLegal.Pages
{
    public class DocumentosModel : PageModel
    {
        private readonly ConexionDB _conexion;
        private readonly IWebHostEnvironment _entorno;

        public DocumentosModel(ConexionDB conexion, IWebHostEnvironment entorno)
        {
            _conexion = conexion;
            _entorno = entorno;
        }

        [BindProperty]
        public IFormFile? Archivo { get; set; }

        public List<DocumentoItem> ListaDocumentos { get; set; } = new();

        public string? Mensaje { get; set; }

        private const long TamanoMaximo = 10 * 1024 * 1024;

        private readonly string[] extensionesPermitidas =
        {
            ".pdf", ".doc", ".docx", ".xls", ".xlsx",
            ".jpg", ".jpeg", ".png"
        };

        public async Task<IActionResult> OnGetAsync()
        {
            int? usuarioId = HttpContext.Session.GetInt32("UsuarioId");

            if (usuarioId == null)
                return RedirectToPage("/Login");

            await CargarDocumentos(usuarioId.Value);

            return Page();
        }

        public async Task<IActionResult> OnPostSubirAsync()
        {
            int? usuarioId = HttpContext.Session.GetInt32("UsuarioId");

            if (usuarioId == null)
                return RedirectToPage("/Login");

            if (Archivo == null || Archivo.Length == 0)
            {
                ModelState.AddModelError(string.Empty, "Seleccioná un archivo.");
                await CargarDocumentos(usuarioId.Value);
                return Page();
            }

            if (Archivo.Length > TamanoMaximo)
            {
                ModelState.AddModelError(string.Empty,
                    "El archivo no puede superar los 10 MB.");
                await CargarDocumentos(usuarioId.Value);
                return Page();
            }

            string extension = Path.GetExtension(Archivo.FileName).ToLowerInvariant();

            if (!extensionesPermitidas.Contains(extension))
            {
                ModelState.AddModelError(string.Empty,
                    "El formato del archivo no está permitido.");
                await CargarDocumentos(usuarioId.Value);
                return Page();
            }

            string carpetaUsuario = Path.Combine(
                _entorno.ContentRootPath,
                "ArchivosPrivados",
                usuarioId.Value.ToString()
            );

            Directory.CreateDirectory(carpetaUsuario);

            string nombreArchivo = Guid.NewGuid().ToString("N") + extension;
            string rutaArchivo = Path.Combine(carpetaUsuario, nombreArchivo);

            try
            {
                using (var stream = new FileStream(rutaArchivo, FileMode.Create))
                {
                    await Archivo.CopyToAsync(stream);
                }

                using SqlConnection conexion = _conexion.ObtenerConexion();
                await conexion.OpenAsync();

                string consulta = @"
                    INSERT INTO Documentos
                    (UsuarioId, NombreOriginal, NombreArchivo, TipoContenido, Tamano)
                    VALUES
                    (@UsuarioId, @NombreOriginal, @NombreArchivo, @TipoContenido, @Tamano)";

                using SqlCommand comando = new(consulta, conexion);

                comando.Parameters.AddWithValue("@UsuarioId", usuarioId.Value);
                comando.Parameters.AddWithValue("@NombreOriginal",
                    Path.GetFileName(Archivo.FileName));
                comando.Parameters.AddWithValue("@NombreArchivo", nombreArchivo);
                comando.Parameters.AddWithValue("@TipoContenido",
                    Archivo.ContentType ?? "application/octet-stream");
                comando.Parameters.AddWithValue("@Tamano", Archivo.Length);

                await comando.ExecuteNonQueryAsync();

                TempData["Mensaje"] = "El documento se subió correctamente.";

                return RedirectToPage("/Documentos");
            }
            catch
            {
                if (System.IO.File.Exists(rutaArchivo))
                    System.IO.File.Delete(rutaArchivo);

                ModelState.AddModelError(string.Empty,
                    "Ocurrió un error al guardar el documento. Intentá nuevamente.");

                await CargarDocumentos(usuarioId.Value);
                return Page();
            }
        }

        public async Task<IActionResult> OnGetDescargarAsync(int id)
        {
            int? usuarioId = HttpContext.Session.GetInt32("UsuarioId");

            if (usuarioId == null)
                return RedirectToPage("/Login");

            using SqlConnection conexion = _conexion.ObtenerConexion();
            await conexion.OpenAsync();

            string consulta = @"
                SELECT NombreOriginal, NombreArchivo, TipoContenido
                FROM Documentos
                WHERE Id = @Id AND UsuarioId = @UsuarioId";

            using SqlCommand comando = new(consulta, conexion);
            comando.Parameters.AddWithValue("@Id", id);
            comando.Parameters.AddWithValue("@UsuarioId", usuarioId.Value);

            using SqlDataReader reader = await comando.ExecuteReaderAsync();

            if (!await reader.ReadAsync())
                return NotFound();

            string nombreOriginal = reader.GetString(0);
            string nombreArchivo = reader.GetString(1);
            string tipoContenido = reader.IsDBNull(2)
                ? "application/octet-stream"
                : reader.GetString(2);

            await reader.CloseAsync();

            string rutaArchivo = Path.Combine(
                _entorno.ContentRootPath,
                "ArchivosPrivados",
                usuarioId.Value.ToString(),
                nombreArchivo
            );

            if (!System.IO.File.Exists(rutaArchivo))
                return NotFound();

            return PhysicalFile(rutaArchivo, tipoContenido, nombreOriginal);
        }

        public async Task<IActionResult> OnGetVerAsync(int id)
        {
            int? usuarioId = HttpContext.Session.GetInt32("UsuarioId");

            if (usuarioId == null)
                return RedirectToPage("/Login");

            using SqlConnection conexion = _conexion.ObtenerConexion();
            await conexion.OpenAsync();

            string consulta = @"
                SELECT NombreArchivo
                FROM Documentos
                WHERE Id = @Id AND UsuarioId = @UsuarioId";

            using SqlCommand comando = new(consulta, conexion);
            comando.Parameters.AddWithValue("@Id", id);
            comando.Parameters.AddWithValue("@UsuarioId", usuarioId.Value);

            object? resultado = await comando.ExecuteScalarAsync();

            if (resultado == null)
                return NotFound();

            string nombreArchivo = Convert.ToString(resultado)!;
            string extension = Path.GetExtension(nombreArchivo).ToLowerInvariant();

            string[] extensionesVisualizables =
            {
                ".pdf", ".jpg", ".jpeg", ".png"
            };

            if (!extensionesVisualizables.Contains(extension))
                return BadRequest("Este tipo de archivo no se puede visualizar directamente.");

            string rutaArchivo = Path.Combine(
                _entorno.ContentRootPath,
                "ArchivosPrivados",
                usuarioId.Value.ToString(),
                nombreArchivo
            );

            if (!System.IO.File.Exists(rutaArchivo))
                return NotFound();

            var proveedor = new FileExtensionContentTypeProvider();

            if (!proveedor.TryGetContentType(nombreArchivo, out string? tipoContenido))
                tipoContenido = "application/octet-stream";

            return PhysicalFile(rutaArchivo, tipoContenido);
        }

        public async Task<IActionResult> OnPostEliminarAsync(int id)
        {
            int? usuarioId = HttpContext.Session.GetInt32("UsuarioId");

            if (usuarioId == null)
                return RedirectToPage("/Login");

            string? nombreArchivo = null;

            using (SqlConnection conexion = _conexion.ObtenerConexion())
            {
                await conexion.OpenAsync();

                string consulta = @"
                    SELECT NombreArchivo
                    FROM Documentos
                    WHERE Id = @Id AND UsuarioId = @UsuarioId";

                using (SqlCommand comando = new(consulta, conexion))
                {
                    comando.Parameters.AddWithValue("@Id", id);
                    comando.Parameters.AddWithValue("@UsuarioId", usuarioId.Value);

                    object? resultado = await comando.ExecuteScalarAsync();

                    if (resultado == null)
                        return NotFound();

                    nombreArchivo = Convert.ToString(resultado);
                }

                string eliminar = @"
                    DELETE FROM Documentos
                    WHERE Id = @Id AND UsuarioId = @UsuarioId";

                using (SqlCommand comando = new(eliminar, conexion))
                {
                    comando.Parameters.AddWithValue("@Id", id);
                    comando.Parameters.AddWithValue("@UsuarioId", usuarioId.Value);

                    await comando.ExecuteNonQueryAsync();
                }
            }

            string rutaArchivo = Path.Combine(
                _entorno.ContentRootPath,
                "ArchivosPrivados",
                usuarioId.Value.ToString(),
                nombreArchivo!
            );

            if (System.IO.File.Exists(rutaArchivo))
                System.IO.File.Delete(rutaArchivo);

            TempData["Mensaje"] = "El documento se eliminó correctamente.";

            return RedirectToPage("/Documentos");
        }

        private async Task CargarDocumentos(int usuarioId)
        {
            ListaDocumentos.Clear();

            using SqlConnection conexion = _conexion.ObtenerConexion();
            await conexion.OpenAsync();

            string consulta = @"
                SELECT Id, NombreOriginal, Tamano, FechaSubida
                FROM Documentos
                WHERE UsuarioId = @UsuarioId
                ORDER BY FechaSubida DESC";

            using SqlCommand comando = new(consulta, conexion);
            comando.Parameters.AddWithValue("@UsuarioId", usuarioId);

            using SqlDataReader reader = await comando.ExecuteReaderAsync();

            while (await reader.ReadAsync())
            {
                ListaDocumentos.Add(new DocumentoItem
                {
                    Id = reader.GetInt32(0),
                    NombreOriginal = reader.GetString(1),
                    Tamano = reader.IsDBNull(2) ? 0 : reader.GetInt64(2),
                    FechaSubida = reader.GetDateTime(3)
                });
            }
        }

        public class DocumentoItem
        {
            public int Id { get; set; }
            public string NombreOriginal { get; set; } = string.Empty;
            public long Tamano { get; set; }
            public DateTime FechaSubida { get; set; }

            public string TamanoLegible
            {
                get
                {
                    return Tamano >= 1024 * 1024
                        ? $"{Tamano / (1024.0 * 1024.0):0.##} MB"
                        : $"{Tamano / 1024.0:0.##} KB";
                }
            }
        }
    }
}
