
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Identity;
using Microsoft.Data.SqlClient;
using AsesoriaLegal.Datos;

namespace AsesoriaLegal.Pages
{
    public class RegistroModel : PageModel
    {
        private readonly ConexionDB _conexion;

        public RegistroModel(ConexionDB conexion)
        {
            _conexion = conexion;
        }

        [BindProperty]
        public DatosRegistro Usuario { get; set; } = new();

        public void OnGet()
        {
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
                return Page();

            using SqlConnection conexion = _conexion.ObtenerConexion();

            await conexion.OpenAsync();

            string verificar = @"
                SELECT COUNT(*)
                FROM Usuarios
                WHERE Correo = @Correo
                   OR NombreUsuario = @NombreUsuario";

            using (SqlCommand comando = new(verificar, conexion))
            {
                comando.Parameters.AddWithValue("@Correo", Usuario.Correo);
                comando.Parameters.AddWithValue("@NombreUsuario", Usuario.NombreUsuario);

                int existe = Convert.ToInt32(await comando.ExecuteScalarAsync());

                if (existe > 0)
                {
                    ModelState.AddModelError(string.Empty,
                        "El correo o nombre de usuario ya está registrado.");
                    return Page();
                }
            }

            var hasher = new PasswordHasher<string>();
            string passwordHash = hasher.HashPassword(
                Usuario.Correo, Usuario.Password);

            string insertar = @"
                INSERT INTO Usuarios
                (Correo, NombreUsuario, Edad, PasswordHash, Nombre, Apellido)
                VALUES
                (@Correo, @NombreUsuario, @Edad, @PasswordHash, @Nombre, @Apellido);

                SELECT CAST(SCOPE_IDENTITY() AS INT);";

            int usuarioId;

            using (SqlCommand comando = new(insertar, conexion))
            {
                comando.Parameters.AddWithValue("@Correo", Usuario.Correo);
                comando.Parameters.AddWithValue("@NombreUsuario", Usuario.NombreUsuario);
                comando.Parameters.AddWithValue("@Edad", Usuario.Edad);
                comando.Parameters.AddWithValue("@PasswordHash", passwordHash);
                comando.Parameters.AddWithValue("@Nombre", Usuario.Nombre);
                comando.Parameters.AddWithValue("@Apellido", Usuario.Apellido);

                usuarioId = Convert.ToInt32(await comando.ExecuteScalarAsync());
            }

            HttpContext.Session.SetInt32("UsuarioId", usuarioId);
            HttpContext.Session.SetString("UsuarioNombre", Usuario.Nombre);

            Response.Cookies.Append(
                "UsuarioNombre",
                Usuario.Nombre,
                new CookieOptions
                {
                    HttpOnly = true,
                    Secure = Request.IsHttps,
                    SameSite = SameSiteMode.Lax,
                    Expires = DateTimeOffset.Now.AddDays(7)
                });

            return RedirectToPage("/Index");
        }
    }

    public class DatosRegistro
    {
        [Required(ErrorMessage = "El nombre es obligatorio.")]
        [StringLength(100)]
        [Display(Name = "Nombre")]
        public string Nombre { get; set; } = string.Empty;

        [Required(ErrorMessage = "El apellido es obligatorio.")]
        [StringLength(100)]
        [Display(Name = "Apellido")]
        public string Apellido { get; set; } = string.Empty;

        [Required(ErrorMessage = "El correo es obligatorio.")]
        [EmailAddress(ErrorMessage = "Ingresá un correo válido.")]
        [StringLength(150)]
        [Display(Name = "Correo electrónico")]
        public string Correo { get; set; } = string.Empty;

        [Required(ErrorMessage = "El nombre de usuario es obligatorio.")]
        [StringLength(50)]
        [Display(Name = "Nombre de usuario")]
        public string NombreUsuario { get; set; } = string.Empty;

        [Required(ErrorMessage = "La edad es obligatoria.")]
        [Range(16, 120, ErrorMessage = "Debés tener más de 15 años.")]
        [Display(Name = "Edad")]
        public int Edad { get; set; }

        [Required(ErrorMessage = "La contraseña es obligatoria.")]
        [MinLength(6, ErrorMessage = "La contraseña debe tener al menos 6 caracteres.")]
        [DataType(DataType.Password)]
        [Display(Name = "Contraseña")]
        public string Password { get; set; } = string.Empty;

        [Required(ErrorMessage = "Confirmá tu contraseña.")]
        [Compare("Password", ErrorMessage = "Las contraseñas no coinciden.")]
        [DataType(DataType.Password)]
        [Display(Name = "Confirmar contraseña")]
        public string ConfirmarPassword { get; set; } = string.Empty;
    }
}
