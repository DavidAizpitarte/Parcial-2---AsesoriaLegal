
CREATE DATABASE AsesoriaLegal;
GO

USE AsesoriaLegal;
GO

-- Tabla de usuarios
CREATE TABLE Usuarios (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Correo NVARCHAR(150) NOT NULL UNIQUE,
    NombreUsuario NVARCHAR(50) NOT NULL UNIQUE,
    Edad INT NOT NULL CHECK (Edad > 15),
    PasswordHash NVARCHAR(255) NOT NULL,
    Nombre NVARCHAR(100) NOT NULL,
    Apellido NVARCHAR(100) NOT NULL,
    FechaRegistro DATETIME2 DEFAULT GETDATE()
);
GO

-- Tabla de documentos
CREATE TABLE Documentos (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    UsuarioId INT NOT NULL,
    NombreOriginal NVARCHAR(255) NOT NULL,
    NombreArchivo NVARCHAR(255) NOT NULL,
    TipoContenido NVARCHAR(150),
    Tamano BIGINT,
    FechaSubida DATETIME2 DEFAULT GETDATE(),

    CONSTRAINT FK_Documentos_Usuarios
    FOREIGN KEY (UsuarioId)
    REFERENCES Usuarios(Id)
);
GO
