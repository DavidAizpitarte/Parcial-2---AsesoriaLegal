
using Microsoft.Data.SqlClient;

namespace AsesoriaLegal.Datos
{
    public class ConexionDB
    {
        private readonly string _cadenaConexion;

        public ConexionDB(IConfiguration configuration)
        {
            _cadenaConexion = configuration.GetConnectionString("ConexionSQL")
                ?? throw new InvalidOperationException(
                    "No se encontró la cadena de conexión ConexionSQL."
                );
        }

        public SqlConnection ObtenerConexion()
        {
            return new SqlConnection(_cadenaConexion);
        }
    }
}
